#include "LinkedList.h"

int parser_parseEmpleados(char* fileName, LinkedList* listaEmpleados)
{

    return 1; // OK
}

