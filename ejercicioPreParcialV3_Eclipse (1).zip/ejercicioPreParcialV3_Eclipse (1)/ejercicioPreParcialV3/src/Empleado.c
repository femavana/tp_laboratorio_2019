#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "Empleado.h"
#include "LinkedList.h"
#include "Parser.h"

Employee* employee_new()
{
	Employee* emp=(Employee*)malloc(sizeof(Employee));
	if(emp != NULL)
	{
	    emp->id = 0;
	    strcpy(emp->nombre," ");
	    emp->horasTrabajadas=0;
	    emp->sueldo = 0;
	}
return emp;
}

Employee* employee_newParametros(char* idStr,char* nombreStr,char* horasTrabajadasStr)
{
	Employee* emp= employee_new();
	int  auxId;
	int  auxHorasTrabajadas;
	//int  auxSueldo;
	if(emp != NULL)
	{
	 auxId=atoi(idStr);
	 auxHorasTrabajadas=atoi(horasTrabajadasStr);
	// auxSueldo=atoi(sueldoStr);
	 employee_setId(emp,auxId);
	 employee_setNombre(emp,nombreStr);
	 employee_setHorasTrabajadas(emp,auxHorasTrabajadas);
	 //employee_setSueldo(emp,auxSueldo);
	}
return emp;
}

void employee_delete(Employee* this)
{
	if(this != NULL)
 {
free(this);
 }
}

int employee_setId(Employee* this,int id)
{
	int ret=-1;
	if(this != NULL && id > 0 )
	{
	this->id=id;
	ret=0;
	}
return ret;
}
int employee_getId(Employee* this,int* id)
{
	int ret=-1;
	if(this != NULL && id > 0 )
	{
	*id=this->id;
	ret=0;
	}
return ret;
}

int employee_setNombre(Employee* this,char* nombre)
{
	int ret=-1;
		   if(this != NULL && nombre > 0 )
		   {
			strcpy(this->nombre,nombre);
		    ret=0;
		   }
return ret;
}
int employee_getNombre(Employee* this,char* nombre)
{
	int ret=-1;
	if(this != NULL && nombre > 0 )
	{
	strcpy(nombre,this->nombre);
	ret=0;
	}
return ret;
}

int employee_setHorasTrabajadas(Employee* this,int horasTrabajadas)
{
 int ret=-1;
		   if(this != NULL && horasTrabajadas > 0 )
		   {
		    this->horasTrabajadas=horasTrabajadas;
		    ret=0;
		   }
return ret;
}
int employee_getHorasTrabajadas(Employee* this,int* horasTrabajadas)
{
	int ret=-1;
	if(this != NULL && horasTrabajadas > 0 )
	{
	*horasTrabajadas=this->horasTrabajadas;
	ret=0;
	}
return ret;
}

int employee_setSueldo(Employee* this,int sueldo)
{
	int ret=-1;
	if(this != NULL && sueldo > 0 )
	{
	this->sueldo=sueldo;
	ret=0;
	}
return ret;
}
int employee_getSueldo(Employee* this,int* sueldo)
{
	int ret=-1;
	if(this != NULL && sueldo > 0 )
	{
    *sueldo=this->sueldo;
	ret=0;
	}
return ret;
}

int employee_loadFromText(char* fileName,LinkedList* this)
{
int ret;
FILE *pFile;

	if(fileName !=NULL && this !=NULL)
	{
	if((pFile=fopen(fileName,"r"))==NULL)
	{
	printf("\nEl archivo no puede ser abierto");
    ret=-1;
	}
	else
	{
	 ret=parser_parseEmpleados(pFile,this);
	 printf("\nSe leyeron del archivo %d elementos en modo texto",ret);
	 if((fclose(pFile))==-1)
	 {
	 printf("\nNo se pudo cerrar el archivo");
	 ret=-2;
	 }
	 }
	ret=1;
	}

return ret;
}
void employee_calcularSueldo(void* p)
{
  int auxHorasTrabajas;
  int auxSueldo;
  Employee* emp1=(Employee*)p;// recibo elemento empleado como void.
  // hacer calculo de sueldo y escribirlo en campo sueldo del empleado

       if(!employee_getHorasTrabajadas(emp1,&auxHorasTrabajas))
       {
       if(auxHorasTrabajas >=80 && auxHorasTrabajas <120)
       {
    	   auxSueldo=auxHorasTrabajas*180;
       }
       else if(auxHorasTrabajas >=120 && auxHorasTrabajas <160)
       {
    	   auxSueldo=auxHorasTrabajas*240;
       }
       else if(auxHorasTrabajas >=160 && auxHorasTrabajas <=240)
       {
    	   auxSueldo=auxHorasTrabajas*350;
       }
          employee_setSueldo(emp1,auxSueldo);
       }
}

 int al_map(LinkedList* this,void (*pFunc)(void*))
{
int ret =-1;
int i;
int size=ll_len(this);
void* pElement=NULL;

       if(this!=NULL)
       {
         for(i=0;i<size;i++)
         {
           pElement=ll_get(this,i);
           if(pElement!=NULL)
           {
              pFunc(pElement);
              ll_set(this,i,pElement);
           }

          }
         ret=0;
       }

return ret;
}


int employee_ListEmployee(LinkedList* this)
{
	int  ret=-1;
	int  i;
	int  size;
	int  auxId;
	char auxNombre[128];
	int  auxHorasTrabajadas;
	int  auxSueldo;
	Employee* emp;

	    size=ll_len(this);
		if(this!= NULL)
		{
	 printf("\n\n__________________________EMPLOYEES____________________________________\n");
	 printf("\nID \tNOMBRE \tHORAS_TRABAJADAS \tSUELDO\n");
	 printf("----------------------------------------------------------------------------");
	       for(i=0;i<size;i++)
	       {
			emp=ll_get(this,i);
			employee_getId(emp,&auxId);
			employee_getNombre(emp,auxNombre);
			employee_getHorasTrabajadas(emp,&auxHorasTrabajadas);
			employee_getSueldo(emp,&auxSueldo);
			printf("\n%d,%s,%d,%d",
		    auxId,auxNombre,auxHorasTrabajadas,auxSueldo);
			}
	      ret=0;
		}
return ret;
}

int employee_generarArchivoSueldos(char* fileName,LinkedList* this)
{
	int ret=1;
	int i;
	int  auxId;
	char auxNombre[128];
	int  auxHorasTrabajadas;
	int  auxSueldo;
	int  size=ll_len(this);
	FILE *pFile;
	Employee* auxEmp;

	if(fileName !=NULL && this !=NULL)
	{
	   if((pFile=fopen(fileName,"w"))==NULL)
	   {
	   printf("\nEl archivo no puede ser abierto");
	   ret=-1;
	   }
	   else
	   {
	    fprintf(pFile,"id,nombre,horasTrabajadas,sueldo\n");
		for(i=0;i<size;i++)
	    {
		 auxEmp=ll_get(this,i);
		 employee_getId(auxEmp,&auxId);
		 employee_getNombre(auxEmp,auxNombre);
		 employee_getHorasTrabajadas(auxEmp,&auxHorasTrabajadas);
		 employee_getSueldo(auxEmp,&auxSueldo);
		 fprintf(pFile,"%d,%s,%d,%d\n",auxId,auxNombre,auxHorasTrabajadas,auxSueldo);
		 }
		 if((fclose(pFile))==-1)
		 {
			printf("\nNo se pudo cerrar el archivo");
			ret=-2;
		 }
	     else
		 {
	      printf("\nEl archivo de texto se guardo correctamente");
		 }
		 }
	}
return ret;
}
