#include <stdio.h>
#include <stdlib.h>
#include "LinkedList.h"
#include "Empleado.h"

int parser_parseEmpleados(FILE* pFile, LinkedList* this)
{
	int ret=-1;
    char buffer[3][54];
    Employee* auxEmp;

		if(pFile !=NULL && this !=NULL)
	    {
		 fscanf(pFile,"%[^,],%[^,],%[^\n]\n",*(buffer+0),*(buffer+1),*(buffer+2));
	     while(!feof(pFile))
		{
		  fscanf(pFile,"%[^,],%[^,],%[^\n]\n",*(buffer+0),*(buffer+1),*(buffer+2));
		  auxEmp= employee_newParametros(*(buffer+0),*(buffer+1),*(buffer+2));
		  if(!ll_add(this,auxEmp))
		  {
		  ret++;
		  }
	    }
	    }

return ret;
}

