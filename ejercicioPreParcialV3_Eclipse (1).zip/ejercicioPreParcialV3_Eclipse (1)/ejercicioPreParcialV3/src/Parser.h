#ifndef PARSER_H_INCLUDED
#define PARSER_H_INCLUDED
#include "LinkedList.h"
#include "Empleado.h"

int parser_parseEmpleados(FILE* pFile,LinkedList* this);


#endif // PARSER_H_INCLUDED
